Thank you for contributing.
We're trying to keep the module up to date and we're adding new features everytime.
Your contribution help us so much in a lot of ways.

We ask you to keep contributing, and feel free to open as many issues and PR as you need.
Also, we encourage you to stick into the templates prepared for every issue, because that could give us a rough idea of what's going wrong.