# Module: Hello World

The `helloworld` module is one of the default modules of the MagicMirror. It is a simple way to display a static text on the mirror.

For configuration options, please check the [MagicMirror² documentation](https://docs.magicmirror.builders/modules/helloworld.html).
